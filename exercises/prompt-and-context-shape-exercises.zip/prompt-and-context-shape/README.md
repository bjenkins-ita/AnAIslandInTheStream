# OrdersApi — exercise repo for *"While I'm here…"*

This repo is the hands-on companion to the first deep dive in the *Agentic Coding Best Practices* series. It exists to let you run a controlled before/after on a single question: **how much does the scope of what an agent can see change what it does?**

You will run the same bug fix twice, varying only the context you give the agent, and compare the results. The numbers you collect are yours — the post reports what we saw; this repo is so you can check.

## What's in here

A small ASP.NET Core 8 Web API for a fictional "Orders" service, plus a minimal Angular frontend that has nothing to do with the bug. The bug is real: a boundary condition in one controller method behaves incorrectly. The fix is one character. The interesting questions are what the agent reads, what it considers, and what that costs.

See `EXERCISE.md` for the full task description and the exact prompt to hand to your agent. Do not read `EXERCISE.md` expecting it to tell you where the bug is — half the point of this exercise is that *you* don't tell the agent where the bug is either. The hint is in the API docs on the method; the rest is up to whoever's reading.

## Running the app

Two paths. Pick whichever has the least friction on your machine.

### Path A — Docker (closer to a real shop setup)

```
docker compose up -d
cd src/OrdersApi
dotnet run
```

The API starts on `http://localhost:5000` (or whatever your dev profile says). SQL Server runs in the container.

### Path B — SQLite (no Docker required)

```
cd src/OrdersApi
dotnet run --environment Development
```

The Development appsettings points at a local SQLite file. Identical behavior for the purposes of this exercise.

Either way, you should see Swagger at `/swagger` once it's up. The data is seeded automatically on first run.

## Reproducing the bug

Once the app is running:

```
GET /api/orders/customer/1?since=2025-01-15T10:00:00Z
```

If the response includes an order dated exactly `2025-01-15T10:00:00Z`, the bug is present. (It is.)

See `EXERCISE.md` for what to do with this information.

## What you'll need

- .NET 8 SDK
- An agent. The exercise is written to be tool-neutral — Claude (any interface), ChatGPT, Copilot Chat in VS Code, Cursor, or similar all work. `EXERCISE.md` has short notes on how to supply context to each.
- A way to see token counts. Most tools surface this; if yours doesn't, `EXERCISE.md` has a fallback.
- About 30–45 minutes, including setup.

## What's in the repo

```
OrdersApi/
├── docker-compose.yml
├── EXERCISE.md                  ← the task (read this second)
├── README.md                    ← this file
├── OrdersApi.sln
├── src/OrdersApi/               ← the API (where the bug lives)
├── tests/OrdersApi.Tests/       ← one passing test, deliberately narrow
└── client-app/                  ← Angular frontend, deliberately off-topic
```

Approximately 35 files total. Small enough to skim in ten minutes, large enough that "give the agent the whole repo" feels like a real choice.

## A note on what this isn't

This repo is not an example of production-quality .NET code. Several things in it are deliberately imperfect — not the bug, just code a well-meaning engineer would want to clean up. That imperfection is load-bearing for the exercise. Please don't open a PR against it.
