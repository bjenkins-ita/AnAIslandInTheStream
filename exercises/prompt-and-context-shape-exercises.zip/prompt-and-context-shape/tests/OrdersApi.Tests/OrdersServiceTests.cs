using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using OrdersApi.Data;
using OrdersApi.Models;
using OrdersApi.Services;
using Xunit;

namespace OrdersApi.Tests;

public class OrderServiceTests
{
    private static OrdersDbContext MakeContext()
    {
        var options = new DbContextOptionsBuilder<OrdersDbContext>()
            .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
            .Options;
        return new OrdersDbContext(options);
    }

    [Fact]
    public async Task GetOrderByIdAsync_ReturnsOrder_WhenItExists()
    {
        using var context = MakeContext();
        var order = new Order
        {
            CustomerId = 1,
            OrderDate = new DateTime(2025, 1, 1, 0, 0, 0, DateTimeKind.Utc),
            Total = 10m,
            Status = "Completed"
        };
        context.Orders.Add(order);
        await context.SaveChangesAsync();

        var service = new OrderService(context);
        var result = await service.GetOrderByIdAsync(order.Id);

        Assert.NotNull(result);
        Assert.Equal(order.Id, result!.Id);
    }
}
