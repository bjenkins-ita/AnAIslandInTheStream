using System;
using System.Collections.Generic;

namespace OrdersApi.Dtos;

public class OrderDto
{
    public int Id { get; set; }
    public int CustomerId { get; set; }
    public DateTime OrderDate { get; set; }
    public decimal Total { get; set; }
    public string? Status { get; set; }
    public List<OrderLineDto> OrderLines { get; set; } = new();
}
