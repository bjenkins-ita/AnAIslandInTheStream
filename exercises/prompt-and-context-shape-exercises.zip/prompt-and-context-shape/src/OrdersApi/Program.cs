using Microsoft.EntityFrameworkCore;
using OrdersApi.Data;
using OrdersApi.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var connectionString = builder.Configuration.GetConnectionString("OrdersDb")
    ?? "Data Source=orders.db";

// Use SQLite if the connection string looks like a file path, otherwise SQL Server.
// This lets readers run the exercise against either backend without changing code.
if (connectionString.Contains("Data Source=") && connectionString.EndsWith(".db"))
{
    builder.Services.AddDbContext<OrdersDbContext>(opt =>
        opt.UseSqlite(connectionString));
}
else
{
    builder.Services.AddDbContext<OrdersDbContext>(opt =>
        opt.UseSqlServer(connectionString));
}

builder.Services.AddScoped<IOrderService, OrderService>();
builder.Services.AddScoped<ICustomerService, CustomerService>();
builder.Services.AddScoped<IProductService, ProductService>();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<OrdersDbContext>();
    db.Database.EnsureCreated();
    SeedData.Seed(db);
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.MapControllers();

app.Run();
