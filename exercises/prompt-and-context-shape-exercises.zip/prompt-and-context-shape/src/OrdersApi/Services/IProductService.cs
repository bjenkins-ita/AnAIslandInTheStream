using System.Collections.Generic;
using System.Threading.Tasks;
using OrdersApi.Dtos;

namespace OrdersApi.Services;

public interface IProductService
{
    Task<List<ProductDto>> GetAllAsync();
    Task<ProductDto?> GetByIdAsync(int id);
}
