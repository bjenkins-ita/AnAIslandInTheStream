using System.Collections.Generic;
using System.Threading.Tasks;
using OrdersApi.Dtos;

namespace OrdersApi.Services;

public interface ICustomerService
{
    Task<List<CustomerDto>> GetAllAsync();
    Task<CustomerDto?> GetByIdAsync(int id);
}
