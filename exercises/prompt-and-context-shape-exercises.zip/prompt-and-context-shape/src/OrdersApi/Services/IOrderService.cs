using System.Collections.Generic;
using System.Threading.Tasks;
using OrdersApi.Models;

namespace OrdersApi.Services;

public interface IOrderService
{
    Task<List<Order>> GetOrdersForCustomerAsync(int customerId);
    Task<Order?> GetOrderByIdAsync(int id);
    Task<Order> CreateOrderAsync(Order order);
}
