using System;
using System.Collections.Generic;

namespace OrdersApi.Models;

public class Order
{
    public int Id { get; set; }
    public int CustomerId { get; set; }
    public Customer? Customer { get; set; }
    public DateTime OrderDate { get; set; }
    public decimal Total { get; set; }
    public string? Status { get; set; }
    public List<OrderLine> OrderLines { get; set; } = new();
}
