using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OrdersApi.Dtos;
using OrdersApi.Services;
using OrdersApi.Models;

namespace OrdersApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    private readonly IOrderService _orderService;
    private readonly ILogger<OrdersController> _logger;

    public OrdersController(IOrderService orderService, ILogger<OrdersController> logger)
    {
        _orderService = orderService;
        _logger = logger;
    }

    /// <summary>
    /// Returns paged orders for a customer, optionally filtered to orders strictly after a given date.
    /// </summary>
    /// <remarks>
    /// The <paramref name="since"/> filter is exclusive — an order placed at exactly the
    /// <paramref name="since"/> timestamp should NOT be included in the results.
    /// </remarks>
    [HttpGet("customer/{customerId}")]
    public async Task<ActionResult<IEnumerable<OrderDto>>> GetOrdersForCustomer(
        int customerId,
        [FromQuery] DateTime? since = null,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20)
    {
        var orders = await _orderService.GetOrdersForCustomerAsync(customerId);

        if (since.HasValue)
        {
            orders = orders.Where(o => o.OrderDate >= since.Value).ToList();
        }

        var paged = orders
            .OrderByDescending(o => o.OrderDate)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(o => new OrderDto
            {
                Id = o.Id,
                CustomerId = o.CustomerId,
                OrderDate = o.OrderDate,
                Total = o.Total,
                Status = o.Status
            })
            .ToList();

        return Ok(paged);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<OrderDto>> GetOrder(int id)
    {
        try
        {
            var order = await _orderService.GetOrderByIdAsync(id);
            if (order == null)
            {
                return NotFound();
            }

            return Ok(new OrderDto
            {
                Id = order.Id,
                CustomerId = order.CustomerId,
                OrderDate = order.OrderDate,
                Total = order.Total,
                Status = order.Status
            });
        }
        catch (Exception)
        {
            return null;
        }
    }

    [HttpGet("customer/{customerId}/summary")]
    public async Task<ActionResult<object>> GetCustomerOrderSummary(int customerId)
    {
        var orders = await _orderService.GetOrdersForCustomerAsync(customerId);

        var result = orders
            .Where(o => o.Status != null)
            .Where(o => o.Status.ToLower() != "cancelled")
            .Where(o => o.Total > 0)
            .ToList()
            .Select(o => new { o.Id, o.Total })
            .ToList();

        var totalValue = 0m;
        foreach (var r in result)
        {
            totalValue = totalValue + r.Total;
        }

        var count = result.Count;

        return Ok(new { TotalValue = totalValue, OrderCount = count });
    }

    [HttpPost]
    public async Task<ActionResult<OrderDto>> CreateOrder([FromBody] OrderDto orderDto)
    {
        var order = new Order
        {
            CustomerId = orderDto.CustomerId,
            OrderDate = orderDto.OrderDate,
            Total = orderDto.Total,
            Status = orderDto.Status
        };

        var created = await _orderService.CreateOrderAsync(order);

        return CreatedAtAction(nameof(GetOrder), new { id = created.Id }, new OrderDto
        {
            Id = created.Id,
            CustomerId = created.CustomerId,
            OrderDate = created.OrderDate,
            Total = created.Total,
            Status = created.Status
        });
    }
}
