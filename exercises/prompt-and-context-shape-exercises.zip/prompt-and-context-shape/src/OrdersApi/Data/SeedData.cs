using System;
using System.Linq;
using OrdersApi.Models;

namespace OrdersApi.Data;

public static class SeedData
{
    public static void Seed(OrdersDbContext context)
    {
        if (context.Customers.Any())
        {
            return;
        }

        var customer1 = new Customer { Name = "Acme Corp", Email = "orders@acme.example" };
        var customer2 = new Customer { Name = "Globex Inc", Email = "orders@globex.example" };
        context.Customers.AddRange(customer1, customer2);
        context.SaveChanges();

        var products = new[]
        {
            new Product { Name = "Widget A", Sku = "WDG-A", Price = 9.99m },
            new Product { Name = "Widget B", Sku = "WDG-B", Price = 19.99m },
            new Product { Name = "Gizmo",    Sku = "GZM-01", Price = 49.99m }
        };
        context.Products.AddRange(products);
        context.SaveChanges();

        var orders = new[]
        {
            new Order
            {
                CustomerId = customer1.Id,
                OrderDate = new DateTime(2025, 1, 1, 9, 0, 0, DateTimeKind.Utc),
                Total = 29.97m,
                Status = "Completed"
            },
            new Order
            {
                CustomerId = customer1.Id,
                OrderDate = new DateTime(2025, 1, 10, 14, 30, 0, DateTimeKind.Utc),
                Total = 59.99m,
                Status = "Completed"
            },
            new Order
            {
                CustomerId = customer1.Id,
                OrderDate = new DateTime(2025, 1, 15, 10, 0, 0, DateTimeKind.Utc),
                Total = 99.98m,
                Status = "Completed"
            },
            new Order
            {
                CustomerId = customer1.Id,
                OrderDate = new DateTime(2025, 1, 20, 11, 15, 0, DateTimeKind.Utc),
                Total = 149.99m,
                Status = "Completed"
            },
            new Order
            {
                CustomerId = customer2.Id,
                OrderDate = new DateTime(2025, 1, 5, 16, 0, 0, DateTimeKind.Utc),
                Total = 9.99m,
                Status = "Cancelled"
            }
        };

        context.Orders.AddRange(orders);
        context.SaveChanges();
    }
}
