# Exercise: the same bug, two ways (plus an encouraged cross-tier extension)

You're going to fix the same bug twice on a single strong model, varying how much of the codebase the agent can see between runs — wide context (the whole repo) and narrow context (one file). Those two runs are the core of the exercise. Then, if you want to see the article's cross-tier nuance with your own numbers, you can repeat the same two runs on a cheaper model. That's the encouraged extension.

The bug is real, the fix is small, and the interesting question is what *else* happens along the way — and how that *else* differs between a wide and narrow context. The optional cross-tier pass adds a second axis: whether a cheaper model handles the same context the same way.

Budget about 30–45 minutes for the core two runs, including setup. Add another 15–20 minutes if you do the cross-tier extension. Each individual run is short; the time is mostly spent resetting state and capturing numbers between them.

---

## Before you start

1. **Get the app running.** Either path from the top-level `README.md` is fine — Docker or SQLite. Confirm you can hit `GET /api/orders/customer/1?since=2025-01-15T10:00:00Z` and get back a response. (The bug will be visible in that response, if you know what to look for. Don't spoil it for yourself by digging yet.)

2. **Get a clean git state.** This exercise uses `git diff` to measure what the agent changed. From the repo root:

   ```
   git init
   git add .
   git commit -m "Starting state"
   ```

   (If the repo already has a git history, skip this — just make sure you're on a clean working tree.)

3. **Pick your agent and a strong model.** Any of these work: Claude (web/desktop/Code), ChatGPT, Copilot Chat in VS Code, Cursor, or a similar tool. For the core two runs you only need one strong model — the article-author's reference was Claude Sonnet 4.6, but any frontier-tier model your tool offers (Sonnet, GPT-5, Gemini Pro, and so on) is fine. **If you want to do the cross-tier extension**, pick a tool that also exposes a cheaper tier on the same family (Sonnet/Haiku, GPT-5/GPT-5-mini, Gemini Pro/Flash, and so on); you'll repeat the two runs on the cheaper one. See "Tool notes" at the end for how to supply context on each.

4. **Get ready to capture numbers.** The "Capture sheet" section at the end has a four-column grid — two columns for the core runs, two more for the cross-tier extension — with a few numbers and a short checklist per run. Ten minutes of work, total. If you skip the extension, leave the cheaper-tier columns blank; that's a valid result and the section explains why.

---

## The bug report

This is the bug report you'll give to the agent — verbatim, on every run. Do not modify it. The prompt being identical across every run you do is what makes the comparison valid.

> **Bug: `GetOrdersForCustomer` returns orders on the boundary of the `since` filter.**
>
> Repro: start the API, then call
> `GET /api/orders/customer/1?since=2025-01-15T10:00:00Z`
>
> Expected: no order dated exactly `2025-01-15T10:00:00Z` in the response.
> Actual: the order dated exactly `2025-01-15T10:00:00Z` is returned.
>
> The endpoint's documentation says the `since` filter is exclusive (strictly after). The implementation disagrees. Please fix.

That's it. No guidance on which file, no guidance on scope, no guidance on whether to add a test. A bug report a tester might file. Give the agent this, and see what comes back.

---

## The matrix

The core path is two runs on a strong model: wide context vs narrow context, same bug report verbatim on each. The cross-tier extension repeats those same two runs on a cheaper model, filling the right-hand column of the grid.

|  | Strong model (core) | Cheaper model (optional extension) |
|---|---|---|
| **Wide context** (whole repo) | Run A-strong | Run A-cheap |
| **Narrow context** (one file) | Run B-strong | Run B-cheap |

The order doesn't matter; the cleanliness of each run does. Reset the working tree and start a fresh session between every cell.

---

## Run A — wide context (strong model)

Give the agent **the whole repo** as context, then paste the bug report.

How you give it "the whole repo" depends on the tool (see "Tool notes"). The principle is: whatever the tool considers "available codebase," it should include everything under `OrdersApi/` — API, tests, migrations, Angular frontend, config files, the lot.

Let the agent do its thing. Accept its proposed edits into your working tree.

**Capture Run A-strong results on the capture sheet before doing anything else.** Don't revert yet.

Then:

```
git reset --hard HEAD
```

**Cross-tier extension (optional but encouraged).** If you're running the cross-tier pass, switch the model to the cheaper tier and start a fresh session. A model switch counts as a fresh start — don't carry chat history from the strong-model run into the cheaper-model run. The "Tool notes" section spells out what "fresh session" means for each tool, including model switches. Re-give the agent the whole repo, paste the same bug report, accept the edits, **capture Run A-cheap results**. If you're skipping the extension, leave the Run A-cheap column blank and continue to Run B.

---

## Run B — narrow context (strong model)

Reset to a clean state:

```
git reset --hard HEAD
```

**Start a fresh session.** This is the most important step in the exercise, and the easiest one to skip. "Fresh session" means at minimum: run `/clear` (or your tool's equivalent) inside the agent. For thoroughness, restart the agent process entirely — close and reopen the CLI, the desktop app, the browser tab, whichever your tool uses. Same-session reuse leaks the previous run's reasoning into this one and confounds the comparison: the agent already knows where the bug is, what it looks like, and what it just changed. `git reset --hard HEAD` resets the working tree, not the agent's memory. The "Tool notes" section below spells out what "fresh session" means per tool, and reminds you that **switching model tiers also counts as a fresh start** (relevant if you're doing the cross-tier extension).

Make sure you're back on the strong model. Give the agent **only `src/OrdersApi/Controllers/OrdersController.cs`** as context. Nothing else. Then paste the same bug report — the exact same words.

How you give it "just this one file" depends on the tool (see "Tool notes"). If your tool doesn't have a clean way to restrict context to a single file, do the best you can: close other editor tabs, start a fresh chat with only the file pasted in, disable project-wide indexing, whatever the tool offers.

Let the agent do its thing. Accept its proposed edits. **Capture Run B-strong results.**

**Cross-tier extension (optional but encouraged).** If you're running the cross-tier pass, `git reset --hard HEAD` again, switch to the cheaper model, start another fresh session, give the agent only `OrdersController.cs`, paste the bug report, accept the edits, **capture Run B-cheap results**. If you're skipping the extension, leave the Run B-cheap column blank and head to the capture-sheet section.

---

## Capture sheet

A few numbers and a short checklist per run. Copy this into a scratch file, a notebook, a spreadsheet — wherever. Note which model you used in each column header.

The sheet has four columns. The two strong-model columns are the core path and should have numbers in them. The two cheaper-model columns are the cross-tier extension; **if you skipped the extension, leave those columns blank — the empty cells are themselves a finding** (you ran the core comparison, you didn't run the cross-tier one, the sheet should reflect that).

| | Run A-strong (wide) | Run A-cheap (wide) | Run B-strong (narrow) | Run B-cheap (narrow) |
|---|---|---|---|---|
| **Model used** (write the name) | | | | |
| **Request tokens** (observed or estimated) | | | | |
| **Files the agent read** (from the agent's transcript, not the diff) | | | | |
| **Files touched** (`git diff --stat` → count files shown) | | | | |
| **Lines changed** (`git diff --stat` → insertions + deletions) | | | | |
| Did the agent modify anything outside `OrdersController.cs`? | Y / N | Y / N | Y / N | Y / N |
| Did the agent touch any file under `Migrations/`? | Y / N | Y / N | Y / N | Y / N |
| Did the agent make changes unrelated to the boundary bug? | Y / N | Y / N | Y / N | Y / N |
| Did the agent reword the XML doc or change method signatures? | Y / N | Y / N | Y / N | Y / N |

A note on what to expect from this sheet. The bug report is precise enough that a competent agent in any of the arms you run will often land on the same one-character fix, so the diff-shape rows (files touched, lines changed, the four yes/no questions) will frequently look identical across the columns you fill in. That isn't the sheet failing — it's the comparison working. The cost difference lives in the top three numeric rows: how many tokens the agent consumed and how many files it opened to get to the same edit. If your tool surfaces tool-call counts as well, write those down too; they tell the same story.

The core comparison is **within-model** (wide vs narrow on the strong tier — Run A-strong vs Run B-strong); that tells you what context width costs on a single model. If you ran the cross-tier extension, you also have **across-model** (the same context width on each tier — Run A-strong vs Run A-cheap, Run B-strong vs Run B-cheap), which tells you whether the cheaper tier handles the same context the same way the stronger one does. Both axes show up in the cost rows.

**Getting the diff numbers:**

```
git diff --stat
```

The last line reads something like `3 files changed, 42 insertions(+), 5 deletions(-)`. Files touched = 3; lines changed = 42 + 5 = 47.

**Getting the token count:**

- Claude.ai, ChatGPT, Cursor, most chat interfaces show a token or character count on hover or in the footer.
- If your tool hides it, rough estimate: `wc -c` on whatever you pasted, divide by 4. Good enough for this comparison — we're looking for order-of-magnitude differences, not two-significant-figure precision.

**Getting the files-read count:**

- Interactive agents (Claude Code TUI, Cursor, Copilot Chat) print the tool calls they make as they go — count the distinct file paths the agent read. A `Read OrdersController.cs` followed later by another `Read OrdersController.cs` is one file.
- For non-interactive runs (e.g. `claude --print`), see the Claude Code (CLI) tool note below for how to surface the same data.
- If your tool exposes nothing, leave the row blank for that run and note which tool you used. A blank row is still a finding.

---

## After your runs

Look at your numbers. Look at the diffs (`git stash` between runs, then flip between them with `git stash list` / `git stash apply`). The article around this exercise makes claims about what you'll see in the within-model comparison, and — if you ran the cross-tier extension — in the across-model comparison too. You now have your own data to agree or disagree with each of the claims your run covers.

One habit worth building: before you compare your numbers to the article's, write down in one sentence what you *think* each comparison means. It's easier to learn from an exercise when you've committed to a reading before you see someone else's.

---

## Tool notes

Each tool has its own way of supplying context. The main flow above is tool-neutral; this appendix is the tool-specific part.

**Fresh sessions and model switches.** Every run is a fresh session. That includes — if you're doing the cross-tier extension — when you switch from the strong model to the cheaper one (or back). A model switch is a fresh start, not a continuation. Don't carry chat history across model tiers; the previous tier's reasoning would leak into the new one and confound the comparison the same way same-session reuse does.

### Claude Code (CLI)

- **Wide context (Run A-strong, Run A-cheap):** from the `OrdersApi/` directory, start Claude Code. It indexes the working directory by default — that's your "whole repo" context. Pass `--model sonnet` for the strong run and `--model haiku` for the cheaper run (or whichever tier names your CLI version exposes).
- **Narrow context (Run B-strong, Run B-cheap):** start a fresh session. When you send the bug report, reference only `src/OrdersApi/Controllers/OrdersController.cs`. Close other files if the tool has an open-tabs concept.
- **Fresh session:** in interactive mode, `/clear` (or restart the process) is the minimum between every cell, **including when you switch the `--model` flag**. If you're using `claude --print "..."` instead, every invocation is naturally fresh — no `/clear` needed; there's no session to clear, and a different `--model` value is just a different invocation.
- **Token count and tool calls (interactive):** the footer of each message shows token usage, and tool calls (`Read`, `Glob`, `Grep`, `Edit`) print inline as the agent makes them. Count the distinct file paths in `Read` calls for the files-read row.
- **Token count and tool calls (`--print`):** the default `--print` output only emits the assistant's final text, with no usage block or tool-call log. Add `--output-format=json` to get a JSON envelope that includes a `usage` block and the full tool-call sequence; parse it for the token and files-read numbers. If you'd rather not parse JSON, just run the exercise interactively — the footer is easier to read than a usage object.

### Claude.ai (web or desktop)

- **Wide context:** zip the repo (or a subset excluding `bin/`, `obj/`, `node_modules/`) and attach it. Alternatively, use a project with the repo as a source.
- **Narrow context:** **start a new conversation** (or a new project) — do not continue the wide-context chat. Paste the contents of `OrdersController.cs` into the message as a code block, nothing else.
- **Switching model tiers:** use the model selector at the top of the conversation, but only on a brand-new chat — switching the model on an existing conversation keeps that conversation's history, which counts as same-session reuse. Always pair a tier switch with a new chat.
- **Token count:** visible in the project / conversation details.

### ChatGPT

- **Wide context:** zip and attach the repo (paid tiers), or paste the combined contents of the key C# files into the prompt if on a plan without file upload.
- **Narrow context:** **open a new chat** — do not continue the wide-context conversation. Paste only the contents of `OrdersController.cs` as a code block.
- **Switching model tiers:** ChatGPT lets you change models mid-conversation; for this exercise, don't. Open a new chat for every tier switch, the same way you do for every context switch.
- **Token count:** not always surfaced; use `wc -c / 4` estimation.

### Copilot Chat (VS Code)

- **Wide context:** `@workspace` the bug report — this tells Copilot to consider the whole workspace.
- **Narrow context:** **start a new chat thread** (the "+" / new-chat icon in the Copilot Chat panel — do not continue the wide-context thread). Open only `OrdersController.cs`, close all other editor tabs, and use plain chat (no `@workspace`).
- **Switching model tiers:** Copilot Chat's model picker applies to the active thread. Open a new thread when you change tiers so the new model isn't reading the previous tier's transcript.
- **Token count:** not always surfaced; estimation fallback applies.

### Cursor

- **Wide context:** use "Codebase" context (`@Codebase`) with the bug report.
- **Narrow context:** **start a new chat** (Cmd/Ctrl-N inside the chat panel, or the new-chat button — do not continue the wide-context chat). Use only `@File OrdersController.cs` context, no codebase reference.
- **Switching model tiers:** Cursor's model dropdown is per-chat; open a fresh chat for every tier switch as well as every context switch.
- **Token count:** visible in some views; estimation fallback otherwise.

If you're using a tool not on this list: the principle is "everything available" vs. "one file, explicitly," and — if you're running the cross-tier extension — repeated on each model tier. Whatever your tool's closest analogs are. The fresh-session rule applies to every axis you change — context width, model tier, both.

---

## If you want to go further

Optional, not required:

- **A fifth run, narrow context, with a scope note added to the bug report.** Append "Keep the fix minimal — only change what's strictly necessary" to the bug report and run it on the strong model with only `OrdersController.cs` in context. This separates context-driven cost from work prompt wording alone can change. The answer is usually not what you expect.
- **A different agent entirely.** Running the same wide-vs-narrow comparison on a second tool — Copilot if you used Cursor, ChatGPT if you used Claude — adds another axis. (If you also did the cross-tier extension on the first tool, you've now varied tier within one tool *and* tool across two — that's a richer matrix than the article ran.) The direction tends to hold; the magnitudes don't.

Whatever you find, your numbers beat ours. We're more interested in results that contradict the article's write-up than ones that match it.
