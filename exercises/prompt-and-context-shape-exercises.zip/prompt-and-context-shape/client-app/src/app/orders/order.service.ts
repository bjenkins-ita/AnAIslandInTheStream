import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Order {
  id: number;
  customerId: number;
  orderDate: string;
  total: number;
  status: string | null;
}

@Injectable({ providedIn: 'root' })
export class OrderService {
  private readonly baseUrl = '/api/orders';

  constructor(private http: HttpClient) {}

  getOrdersForCustomer(customerId: number, since?: string, page = 1, pageSize = 20): Observable<Order[]> {
    const params: Record<string, string> = {
      page: page.toString(),
      pageSize: pageSize.toString()
    };
    if (since) {
      params['since'] = since;
    }
    return this.http.get<Order[]>(`${this.baseUrl}/customer/${customerId}`, { params });
  }
}
