# client-app

Minimal Angular frontend that exists to represent "realistic adjacent code" in the exercise repo.

**It is not part of the exercise.** The bug you're asked to fix lives in the ASP.NET Core API under `../src/OrdersApi/`.

This folder is here because a realistic line-of-business repo usually has a frontend sitting next to the API, and any agent given the whole repo as context will see it. Watching whether the agent wanders in here on Run A is one of the qualitative signals the exercise captures.

If you want to run it (not required), you'll need Node 18+ and `npm install && npm start` in this directory, with the API already running. Again: not required.
